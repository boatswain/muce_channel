require(['channels/channels'], function(Channels) {
});